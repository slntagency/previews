<?php
// The Gym Enkhuizen: aanvraagformulier, mailt naar de sportschool
header('Content-Type: application/json; charset=utf-8');
header('X-Robots-Tag: noindex');
if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') { http_response_code(405); echo '{"ok":false}'; exit; }
// spam: verborgen veld ingevuld of te snel verstuurd
if (!empty($_POST['website']) || (int)($_POST['t'] ?? 0) < 2500) { echo '{"ok":true}'; exit; }
function regel($s, $max) { $s = trim(str_replace(array("\r", "\n", "\0"), ' ', (string)$s)); return mb_substr($s, 0, $max, 'UTF-8'); }
$naam      = regel($_POST['naam'] ?? '', 80);
$tel       = regel($_POST['tel'] ?? '', 30);
$email     = regel($_POST['email'] ?? '', 120);
$onderwerp = regel($_POST['onderwerp'] ?? 'Aanvraag via de website', 150);
$bericht   = mb_substr(str_replace("\0", '', trim((string)($_POST['bericht'] ?? ''))), 0, 3000, 'UTF-8');
if (mb_strlen($naam, 'UTF-8') < 2 || strlen(preg_replace('/\D/', '', $tel)) < 9 || $bericht === '') { http_response_code(422); echo '{"ok":false}'; exit; }
$naar    = 'thegymenkhuizen@hotmail.com';
$headers = "From: The Gym website <noreply@thegymenkhuizen.nl>\r\n";
if ($email !== '' && filter_var($email, FILTER_VALIDATE_EMAIL)) { $headers .= "Reply-To: " . $email . "\r\n"; }
$headers .= "MIME-Version: 1.0\r\nContent-Type: text/plain; charset=UTF-8\r\nContent-Transfer-Encoding: 8bit\r\n";
$tekst = $bericht . "\r\n\r\n--\r\nVerstuurd via het formulier op www.thegymenkhuizen.nl";
$ok = mail($naar, '=?UTF-8?B?' . base64_encode($onderwerp) . '?=', $tekst, $headers, '-fnoreply@thegymenkhuizen.nl');
echo json_encode(array('ok' => (bool)$ok));
